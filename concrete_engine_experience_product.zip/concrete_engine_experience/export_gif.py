from ce_experience.config import WorldConfig, RuntimeConfig, ExportConfig
from ce_experience.world import SyntheticWorld
from ce_experience.renderer import ExperienceRenderer


def main():
    export = ExportConfig(seconds=20, fps=15)
    world = SyntheticWorld.generate(WorldConfig(size=384))
    runtime = RuntimeConfig(
        fps_interval_ms=int(1000 / export.fps),
        time_step=1 / export.fps,
        particle_count=500,
    )
    renderer = ExperienceRenderer(world, runtime)
    out = renderer.export_gif(export.output_name, seconds=export.seconds, fps=export.fps)
    print(f"Saved {out}")


if __name__ == "__main__":
    main()
