# Concrete Engine Experience

A product foundation for a cinematic synthetic-world AI demo.

This project turns the earlier fractal/prototype idea into a structured product:

- Procedural synthetic world generation
- Sensor simulation layers
- Use-case-specific AI detections
- Concrete Engine telemetry
- Cinematic scene direction
- Live dashboard playback
- Optional GIF export
- Product roadmap and storyboard

## Quick Start

```bash
python3 -m pip install -r requirements.txt
python3 run_experience.py
```

## Export a Short GIF

```bash
python3 export_gif.py
```

The GIF export defaults to a short preview. A full 3-minute export is possible, but it can take a while in pure Matplotlib.

## Product Vision

Concrete Engine Experience is not a screensaver.

It is a visual operating layer that shows how Concrete Engine can:

1. Generate synthetic worlds
2. Simulate sensors
3. Analyze use cases
4. Detect features
5. Scale AI workloads
6. Orchestrate distributed GPU infrastructure

## Folder Structure

```text
ce_experience/
  config.py
  director.py
  world.py
  sensors.py
  detections.py
  telemetry.py
  renderer.py
  product_spec.py
run_experience.py
export_gif.py
PRODUCT_ROADMAP.md
STORYBOARD_3_MIN.md
```
