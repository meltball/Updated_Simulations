import math
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter

from .world import normalize
from .sensors import sensors, scene_layer
from .director import ExperienceDirector
from .detections import DetectionEngine
from .telemetry import telemetry


class ParticleSystem:
    def __init__(self, count, rng):
        self.count = count
        self.rng = rng
        self.x = rng.uniform(0, 1, count)
        self.y = rng.uniform(0, 1, count)
        self.vx = rng.normal(0, 0.0018, count)
        self.vy = rng.normal(0, 0.0018, count)

    def update(self, t, scene_key):
        if scene_key in ("AI_FACTORY", "COMPUTE_GRID"):
            dx = self.x - 0.5
            dy = self.y - 0.5
            angle = np.arctan2(dy, dx) + np.pi / 2
            self.vx += 0.00018 * np.cos(angle)
            self.vy += 0.00018 * np.sin(angle)
        elif scene_key == "BORDER":
            self.vx += 0.00012
            self.vy += 0.00003 * np.sin(t + self.x * 8)
        else:
            self.vx += 0.00002 * np.sin(t + self.y * 5)
            self.vy += 0.00002 * np.cos(t + self.x * 5)

        self.x = (self.x + self.vx) % 1.0
        self.y = (self.y + self.vy) % 1.0
        self.vx *= 0.995
        self.vy *= 0.995


class ExperienceRenderer:
    def __init__(self, world, runtime_config):
        self.world = world
        self.config = runtime_config
        self.director = ExperienceDirector()
        self.detector = DetectionEngine(world.size)
        self.rng = np.random.default_rng(177)
        self.particles = ParticleSystem(runtime_config.particle_count, self.rng)
        self.dynamic_artists = []
        self.t = 0.0

    def render_frame_data(self):
        scene, progress = self.director.scene_at(self.t)
        sensor = sensors(self.world, self.t)
        layer = scene_layer(scene.key, self.world, sensor, self.t)

        # Cinematic pulse while preserving the source-data layer.
        layer = normalize(
            layer
            + 0.045 * np.sin(layer * 18 + self.t * 2.2)
            + 0.020 * self.rng.normal(0, 1, layer.shape)
        )

        detections = self.detector.detections(scene.key, self.world, sensor, self.t)
        tel = telemetry(scene, self.t)
        return scene, progress, layer, detections, tel

    def run(self):
        fig, ax, handles = self.setup_figure()

        def update(_):
            return self.update_matplotlib(ax, handles)

        ani = FuncAnimation(
            fig,
            update,
            interval=self.config.fps_interval_ms,
            blit=False,
            cache_frame_data=False,
        )
        plt.show()
        return ani

    def export_gif(self, output_path, seconds=20, fps=15):
        fig, ax, handles = self.setup_figure()
        total_frames = seconds * fps
        interval = int(1000 / fps)

        def update(_):
            return self.update_matplotlib(ax, handles, fixed_time_step=1 / fps)

        ani = FuncAnimation(
            fig,
            update,
            frames=total_frames,
            interval=interval,
            blit=False,
            cache_frame_data=False,
        )

        ani.save(output_path, writer=PillowWriter(fps=fps))
        plt.close(fig)
        return output_path

    def setup_figure(self):
        scene, _, layer, _, _ = self.render_frame_data()

        fig, ax = plt.subplots(figsize=(10, 10))
        try:
            fig.canvas.manager.set_window_title("Concrete Engine Experience")
        except Exception:
            pass
        ax.set_facecolor("black")
        ax.axis("off")

        im = ax.imshow(layer, cmap=scene.cmap, interpolation="bilinear", animated=True)
        scatter = ax.scatter([], [], s=1.0, alpha=0.50, c="white")

        title = ax.text(0.02, 0.965, "", transform=ax.transAxes, fontsize=14, weight="bold", color="white", family="monospace")
        subtitle = ax.text(0.02, 0.925, "", transform=ax.transAxes, fontsize=8.5, color="white", family="monospace")
        source = ax.text(
            0.02, 0.885, "",
            transform=ax.transAxes,
            fontsize=8,
            color="white",
            family="monospace",
            bbox=dict(boxstyle="round,pad=0.25", facecolor="black", edgecolor="white", alpha=0.25),
        )
        tel_text = ax.text(
            0.02, 0.045, "",
            transform=ax.transAxes,
            fontsize=8.5,
            color="white",
            family="monospace",
            bbox=dict(boxstyle="round,pad=0.35", facecolor="black", edgecolor="white", alpha=0.35),
        )

        handles = {"im": im, "scatter": scatter, "title": title, "subtitle": subtitle, "source": source, "telemetry": tel_text}
        return fig, ax, handles

    def update_matplotlib(self, ax, handles, fixed_time_step=None):
        self.clear_dynamic()
        self.t += fixed_time_step if fixed_time_step is not None else self.config.time_step

        scene, progress, layer, detections, tel = self.render_frame_data()

        handles["im"].set_array(layer)
        handles["im"].set_cmap(scene.cmap)
        handles["title"].set_text(scene.title)
        handles["subtitle"].set_text(f"MISSION: {scene.mission}")
        handles["source"].set_text(f"INPUT: {scene.source}\nMODEL: {scene.model}")
        handles["telemetry"].set_text("  ".join(f"{k}: {v}" for k, v in tel.items()))

        if self.config.show_particles:
            self.particles.update(self.t, scene.key)
            handles["scatter"].set_offsets(np.column_stack([
                self.particles.x * self.world.size,
                self.particles.y * self.world.size,
            ]))

        if self.config.show_detections:
            self.dynamic_artists.extend(self.draw_detections(ax, detections, self.t, scene.key))

        self.dynamic_artists.extend(self.draw_scene_overlays(ax, scene.key, self.t))

        return list(handles.values()) + self.dynamic_artists

    def clear_dynamic(self):
        for artist in self.dynamic_artists:
            try:
                artist.remove()
            except Exception:
                pass
        self.dynamic_artists = []

    def draw_detections(self, ax, detections, t, scene_key):
        artists = []
        size = self.world.size

        for d in detections:
            x, y = d["x"] * size, d["y"] * size
            w, h = d["w"] * size, d["h"] * size
            conf = d["confidence"]
            alpha = 0.45 + 0.35 * conf

            rect = plt.Rectangle((x, y), w, h, fill=False, edgecolor="white", linewidth=1.1, alpha=alpha)
            ax.add_patch(rect)
            artists.append(rect)

            c = min(w, h) * 0.22
            for x1, y1, x2, y2 in [
                (x, y, x + c, y), (x, y, x, y + c),
                (x + w, y, x + w - c, y), (x + w, y, x + w, y + c),
                (x, y + h, x + c, y + h), (x, y + h, x, y + h - c),
                (x + w, y + h, x + w - c, y + h), (x + w, y + h, x + w, y + h - c),
            ]:
                line, = ax.plot([x1, x2], [y1, y2], color="white", linewidth=2.0, alpha=alpha)
                artists.append(line)

            txt = ax.text(
                x, max(8, y - 9),
                f"ID-{d['id']} {d['label']} {conf:.0%} {d['metric_value']}",
                fontsize=7.2,
                color="white",
                family="monospace",
                bbox=dict(boxstyle="round,pad=0.22", facecolor="black", edgecolor="white", alpha=0.48, linewidth=0.55),
            )
            artists.append(txt)

            cx, cy = x + w / 2, y + h / 2
            dot = ax.scatter([cx], [cy], s=12, c="white", alpha=alpha)
            artists.append(dot)

            if scene_key == "BORDER":
                dx = 24 * math.sin(t + d["id"])
                dy = 16 * math.cos(t * 0.7 + d["id"])
                arrow = ax.arrow(cx, cy, dx, dy, color="white", alpha=0.45, width=0.25, head_width=5)
                artists.append(arrow)

        return artists

    def draw_scene_overlays(self, ax, scene_key, t):
        artists = []
        size = self.world.size

        if scene_key == "BORDER":
            cx = cy = size / 2
            angle = t * 1.3
            line, = ax.plot([cx, cx + math.cos(angle) * size * 0.48], [cy, cy + math.sin(angle) * size * 0.48], color="white", alpha=0.28, linewidth=1.4)
            artists.append(line)
            ring = plt.Circle((cx, cy), size * 0.32, fill=False, color="white", alpha=0.18, linewidth=0.8)
            ax.add_patch(ring)
            artists.append(ring)

        if scene_key == "MINING":
            rng = np.random.default_rng(5)
            pts = ax.scatter(rng.uniform(size * 0.18, size * 0.82, 18), rng.uniform(size * 0.22, size * 0.80, 18), s=8, facecolors="none", edgecolors="white", alpha=0.55)
            artists.append(pts)

        if scene_key in ("AI_FACTORY", "COMPUTE_GRID"):
            yx = np.argwhere(self.world.data_centers > 0.72)
            if len(yx):
                sample = yx[::max(1, len(yx) // 30)]
                pts = ax.scatter(sample[:, 1], sample[:, 0], s=28 + 15 * abs(math.sin(t * 2.0)), facecolors="none", edgecolors="white", alpha=0.35)
                artists.append(pts)

        return artists
