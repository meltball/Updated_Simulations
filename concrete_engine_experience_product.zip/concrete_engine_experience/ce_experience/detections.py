import math
import numpy as np
from .world import normalize


class DetectionEngine:
    def __init__(self, size):
        self.size = size

    def top_regions(self, score, count=5, min_distance=52):
        score = score.copy()
        regions = []
        for _ in range(count):
            idx = np.argmax(score)
            y, x = np.unravel_index(idx, score.shape)
            val = float(score[y, x])
            if val < 0.02:
                break

            w = int(34 + 52 * val)
            h = int(24 + 38 * val)

            regions.append({
                "x": max(0, x - w // 2) / self.size,
                "y": max(0, y - h // 2) / self.size,
                "w": min(w, self.size) / self.size,
                "h": min(h, self.size) / self.size,
                "score": val,
            })

            y0, y1 = max(0, y - min_distance), min(self.size, y + min_distance)
            x0, x1 = max(0, x - min_distance), min(self.size, x + min_distance)
            score[y0:y1, x0:x1] *= 0.08

        return regions

    def moving_targets(self, t):
        yy, xx = np.mgrid[0:self.size, 0:self.size]
        field = np.zeros((self.size, self.size))
        targets = [
            (0.25 + 0.18 * math.sin(t * 0.35), 0.30 + 0.10 * math.cos(t * 0.55)),
            (0.62 + 0.15 * math.sin(t * 0.42 + 1.4), 0.48 + 0.16 * math.cos(t * 0.38)),
            (0.72 + 0.10 * math.sin(t * 0.80 + 2.2), 0.72 + 0.08 * math.cos(t * 0.75)),
        ]
        for x, y in targets:
            cx, cy = x * self.size, y * self.size
            dist = (xx - cx) ** 2 + (yy - cy) ** 2
            field += np.exp(-dist / (2 * 7.5 ** 2))
        return normalize(field)

    def detections(self, scene_key, world, sensor, t):
        scene_key = scene_key.upper()

        if scene_key == "MINING":
            score = normalize(0.74 * world.mineral + 0.85 * world.veins + 0.15 * world.faults)
            labels = ["ORE VEIN", "SULFIDE BAND", "FAULT INTERSECTION", "HIGH-DENSITY POCKET", "DRILL TARGET"]
            metric = "ORE"
        elif scene_key == "BORDER":
            score = normalize(0.42 * sensor["thermal"] + 0.48 * sensor["radar"] + self.moving_targets(t))
            labels = ["MOVING OBJECT", "THERMAL SIGNATURE", "DRONE TRACK", "PERIMETER BREACH", "VEHICLE TRACK"]
            metric = "TRACK"
        elif scene_key == "AGRICULTURE":
            stress = normalize(sensor["thermal"] * 0.7 + (1 - sensor["ndvi"]) * 0.5)
            score = stress
            labels = ["WATER STRESS", "LOW NDVI", "CROP HEALTH RISK", "IRRIGATION GAP", "YIELD RISK"]
            metric = "STRESS"
        elif scene_key == "DIGITAL_TWIN":
            score = normalize(0.62 * world.cities + 0.55 * world.roads + 0.72 * world.data_centers + 0.20 * sensor["thermal"])
            labels = ["STRUCTURAL NODE", "HEAT ISLAND", "FLOW BOTTLENECK", "SIMULATION DELTA", "SENSOR ANOMALY"]
            metric = "DELTA"
        elif scene_key == "COMPUTE_GRID":
            score = normalize(0.88 * world.data_centers + 0.58 * world.power + 0.25 * sensor["thermal"])
            labels = ["ACTIVE GPU CLUSTER", "DATAFLOW HOTSPOT", "STORAGE BURST", "POWER NODE", "COOLING ZONE"]
            metric = "LOAD"
        else:
            score = normalize(0.75 * world.data_centers + 0.45 * sensor["thermal"] + 0.30 * sensor["radar"])
            labels = ["MODEL CONVERGENCE", "SYNTHETIC DATA STREAM", "ORCHESTRATION EVENT", "LATENCY DROP", "TRAINING HOTSPOT"]
            metric = "CONF"

        out = []
        for i, r in enumerate(self.top_regions(score)):
            conf = min(0.99, 0.66 + 0.32 * r["score"] + 0.02 * math.sin(t + i))
            out.append({
                **r,
                "id": 100 + i,
                "label": labels[i % len(labels)],
                "confidence": conf,
                "metric_value": self.metric(metric, r["score"], t, i),
            })
        return out

    def metric(self, metric, score, t, i):
        if metric == "ORE":
            return f"ORE {score * 100:.0f}%"
        if metric == "TRACK":
            return f"VEL {12 + 10 * abs(math.sin(t + i)):.1f}m/s"
        if metric == "STRESS":
            return f"STRESS {score * 100:.0f}%"
        if metric == "DELTA":
            return f"DELTA {score * 100:.0f}%"
        if metric == "LOAD":
            return f"LOAD {score * 100:.0f}%"
        return f"CONF {score * 100:.0f}%"
