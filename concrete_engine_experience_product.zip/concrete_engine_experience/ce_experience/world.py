from dataclasses import dataclass
import numpy as np


def normalize(a):
    a = a.astype(float)
    mn, mx = np.min(a), np.max(a)
    if mx - mn < 1e-9:
        return np.zeros_like(a)
    return (a - mn) / (mx - mn)


def smooth(a, rounds=2):
    for _ in range(rounds):
        a = (
            a
            + np.roll(a, 1, 0)
            + np.roll(a, -1, 0)
            + np.roll(a, 1, 1)
            + np.roll(a, -1, 1)
        ) / 5.0
    return a


def fbm(size, rng, octaves=7, persistence=0.58):
    field = np.zeros((size, size))
    amp = 1.0
    total = 0.0

    for i in range(octaves):
        grid = max(4, size // (2 ** (i + 3)))
        coarse = rng.random((grid, grid))
        scale = int(np.ceil(size / grid))
        up = np.kron(coarse, np.ones((scale, scale)))[:size, :size]
        up = smooth(up, rounds=2 + i)
        field += amp * up
        total += amp
        amp *= persistence

    return normalize(field / total)


def gradient(a):
    gy, gx = np.gradient(a)
    return normalize(np.sqrt(gx * gx + gy * gy))


def lines_layer(size, rng, count=7):
    yy, xx = np.mgrid[0:size, 0:size]
    out = np.zeros((size, size))

    for _ in range(count):
        angle = rng.uniform(0, np.pi)
        cx, cy = rng.uniform(0, size), rng.uniform(0, size)
        dist = np.abs((xx - cx) * np.cos(angle) + (yy - cy) * np.sin(angle))
        width = rng.uniform(1.5, 4.5)
        out += np.exp(-(dist ** 2) / (2 * width ** 2))

    return normalize(out)


@dataclass
class SyntheticWorld:
    size: int
    terrain: np.ndarray
    slope: np.ndarray
    faults: np.ndarray
    mineral: np.ndarray
    veins: np.ndarray
    roads: np.ndarray
    power: np.ndarray
    cities: np.ndarray
    data_centers: np.ndarray

    @classmethod
    def generate(cls, config):
        rng = np.random.default_rng(config.seed)
        size = config.size

        terrain = fbm(size, rng, config.octaves, config.roughness)

        yy, xx = np.mgrid[0:size, 0:size]
        radial = np.sqrt((xx - size / 2) ** 2 + (yy - size / 2) ** 2) / (size / 1.35)
        terrain = normalize(np.clip(terrain - radial * 0.28, 0, 1))

        slope = gradient(terrain)
        faults = lines_layer(size, rng, 8)

        deep = fbm(size, rng, 5, 0.62)
        elevation_band = np.exp(-((terrain - 0.56) ** 2) / 0.035)
        mineral = normalize(0.42 * faults + 0.25 * deep + 0.22 * slope + 0.25 * elevation_band)
        veins = normalize((faults > 0.72).astype(float) * (0.45 + deep))

        flat = (1 - slope) * (terrain > 0.38) * (terrain < 0.72)
        roads = np.zeros_like(terrain)
        cities = np.zeros_like(terrain)

        centers = []
        score = flat.copy()
        for _ in range(4):
            idx = np.argmax(score + rng.random(score.shape) * 0.05)
            y, x = np.unravel_index(idx, score.shape)
            centers.append((x, y))
            dist = np.sqrt((xx - x) ** 2 + (yy - y) ** 2)
            cities += np.exp(-(dist ** 2) / (2 * rng.uniform(13, 24) ** 2))
            score[max(0, y-70):min(size, y+70), max(0, x-70):min(size, x+70)] *= 0.1

        for (x1, y1), (x2, y2) in zip(centers, centers[1:] + centers[:1]):
            steps = int(max(abs(x2 - x1), abs(y2 - y1))) + 1
            xs = np.linspace(x1, x2, steps).astype(int)
            ys = np.linspace(y1, y2, steps).astype(int)
            roads[ys, xs] = 1.0

        roads = smooth(roads, 3)
        roads = normalize(roads)
        power = normalize(np.roll(roads, 6, axis=0) * 0.8)

        dc_score = power * flat
        data_centers = np.zeros_like(terrain)
        for _ in range(3):
            idx = np.argmax(dc_score + rng.random(dc_score.shape) * 0.03)
            y, x = np.unravel_index(idx, dc_score.shape)
            dist = np.sqrt((xx - x) ** 2 + (yy - y) ** 2)
            data_centers += np.exp(-(dist ** 2) / (2 * 8 ** 2))
            dc_score[max(0, y-85):min(size, y+85), max(0, x-85):min(size, x+85)] *= 0.15

        return cls(
            size=size,
            terrain=terrain,
            slope=slope,
            faults=faults,
            mineral=normalize(mineral),
            veins=normalize(veins),
            roads=roads,
            power=power,
            cities=normalize(cities),
            data_centers=normalize(data_centers),
        )
