import math


def telemetry(scene, t):
    pulse = 0.5 + 0.5 * math.sin(t * 1.7)
    return {
        "GPU LOAD": f"{min(0.99, scene.gpu_load + 0.025 * pulse):.0%}",
        "GPUs": f"{scene.gpu_count:,}",
        "NODES": f"{scene.nodes:,}",
        "NETWORK": f"{min(0.99, scene.network + 0.03 * pulse):.0%}",
        "STORAGE": f"{min(0.99, scene.storage + 0.02 * pulse):.0%}",
        "POWER": f"{min(0.99, scene.power + 0.015 * pulse):.0%}",
        "PUE": f"{1.02 + (1 - scene.power) * 0.08:.2f}",
        "BATCH": f"{int(12000 + 4000 * pulse):,}",
        "LATENCY": f"{7.5 + 2.0 * (1 - scene.network):.1f} ms",
        "STATUS": "ANALYZING",
    }
