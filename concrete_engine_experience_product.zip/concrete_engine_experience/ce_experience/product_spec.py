PRODUCT_NAME = "Concrete Engine Experience"

TAGLINE = "Generate. Analyze. Simulate. Scale."

CORE_MESSAGE = (
    "Concrete Engine turns synthetic worlds, sensor data, and distributed "
    "compute into operational AI intelligence."
)

USE_CASES = [
    "AI Factory",
    "Mining",
    "Border Monitoring",
    "Agriculture",
    "Digital Twin",
    "Sovereign Compute Grid",
]

PRODUCT_MODULES = [
    "Synthetic World Generator",
    "Sensor Simulator",
    "AI Detection Engine",
    "Telemetry Engine",
    "Cinematic Director",
    "Renderer",
    "Export Pipeline",
]
