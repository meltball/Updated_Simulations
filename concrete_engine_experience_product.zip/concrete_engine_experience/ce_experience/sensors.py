import numpy as np
from .world import normalize


def sensors(world, t):
    size = world.size
    yy, xx = np.mgrid[0:size, 0:size]

    rgb = normalize(0.52 * world.terrain + 0.22 * world.cities + 0.14 * world.roads + 0.20 * world.slope)

    thermal = normalize(
        0.25 * world.terrain
        + 0.75 * world.cities
        + 0.90 * world.data_centers
        + 0.20 * world.roads
        + 0.05 * np.sin(xx / 10 + t)
    )

    hyperspectral = normalize(0.80 * world.mineral + 0.65 * world.veins + 0.18 * world.terrain)

    radar = normalize(
        0.55 * world.slope
        + 0.35 * world.roads
        + 0.30 * world.power
        + 0.10 * np.sin((xx + yy) / 18 - t * 2.0)
    )

    lidar = normalize(world.terrain + 0.12 * world.cities + 0.05 * world.data_centers)

    vegetation = normalize((1 - world.terrain) * (world.terrain > 0.35) * (world.terrain < 0.63))
    ndvi = normalize(0.75 * vegetation - 0.25 * thermal)

    return {
        "rgb": rgb,
        "thermal": thermal,
        "hyperspectral": hyperspectral,
        "radar": radar,
        "lidar": lidar,
        "ndvi": ndvi,
    }


def scene_layer(scene_key, world, sensor, t):
    scene_key = scene_key.upper()

    if scene_key == "MINING":
        return normalize(0.55 * sensor["hyperspectral"] + 0.30 * world.terrain + 0.28 * world.veins)

    if scene_key == "BORDER":
        return normalize(0.47 * sensor["thermal"] + 0.38 * sensor["radar"] + 0.20 * world.roads)

    if scene_key == "AGRICULTURE":
        stress = normalize(sensor["thermal"] * 0.75 + (1 - sensor["ndvi"]) * 0.45)
        return normalize(0.58 * sensor["ndvi"] + 0.38 * stress + 0.10 * world.roads)

    if scene_key == "DIGITAL_TWIN":
        return normalize(0.35 * sensor["lidar"] + 0.28 * world.cities + 0.28 * world.roads + 0.18 * world.data_centers)

    if scene_key == "COMPUTE_GRID":
        return normalize(0.55 * world.data_centers + 0.35 * world.power + 0.30 * world.roads + 0.22 * sensor["thermal"])

    return normalize(0.44 * sensor["thermal"] + 0.36 * world.data_centers + 0.25 * sensor["radar"] + 0.25 * world.power)
