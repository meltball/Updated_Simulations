from dataclasses import dataclass


@dataclass
class WorldConfig:
    seed: int = 72
    size: int = 512
    octaves: int = 7
    roughness: float = 0.58


@dataclass
class RuntimeConfig:
    fps_interval_ms: int = 40
    time_step: float = 0.045
    particle_count: int = 900
    show_detections: bool = True
    show_particles: bool = True
    show_telemetry: bool = True


@dataclass
class ExportConfig:
    seconds: int = 20
    fps: int = 15
    output_name: str = "concrete_engine_experience_preview.gif"
