from ce_experience.config import WorldConfig, RuntimeConfig
from ce_experience.world import SyntheticWorld
from ce_experience.renderer import ExperienceRenderer


def main():
    world = SyntheticWorld.generate(WorldConfig())
    renderer = ExperienceRenderer(world, RuntimeConfig())
    renderer.run()


if __name__ == "__main__":
    main()
