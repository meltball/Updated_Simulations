from ce_experience.config import WorldConfig, RuntimeConfig
from ce_experience.world import SyntheticWorld
from ce_experience.renderer import ExperienceRenderer


def main():
    # This is heavy in pure Matplotlib. Use for final export once the preview looks right.
    seconds = 180
    fps = 15
    world = SyntheticWorld.generate(WorldConfig(size=384))
    runtime = RuntimeConfig(
        fps_interval_ms=int(1000 / fps),
        time_step=1 / fps,
        particle_count=500,
    )
    renderer = ExperienceRenderer(world, runtime)
    out = renderer.export_gif("concrete_engine_experience_3min.gif", seconds=seconds, fps=fps)
    print(f"Saved {out}")


if __name__ == "__main__":
    main()
