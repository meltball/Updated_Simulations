# Concrete Engine Experience Product Roadmap

## Phase 1 — Prototype Product Foundation

Status: included in this repo.

- Synthetic terrain generation
- Geology/mineral layer
- Roads, cities, power, data centers
- Sensor layers: RGB, thermal, radar, LiDAR, hyperspectral, NDVI-like agriculture
- Use-case detections
- Telemetry overlay
- Live demo runner
- GIF export path

## Phase 2 — Cinematic Upgrade

Replace Matplotlib with a real-time presentation layer.

Recommended paths:

1. Blender for cinematic 3D rendered video
2. Unreal Engine for interactive real-time demo
3. WebGL/Three.js for browser-based investor demo
4. TouchDesigner for stage/pitch visuals

## Phase 3 — Real Product Interface

Add:

- scenario selector
- seed selector
- use-case presets
- export MP4
- voiceover timeline
- dashboard controls
- brand styling
- real telemetry input
- synthetic dataset export

## Phase 4 — Concrete Engine Integration

Add:

- job scheduler events
- GPU utilization telemetry
- distributed node map
- workload queue
- model progress
- storage/network/power optimization
- real user-provided datasets
