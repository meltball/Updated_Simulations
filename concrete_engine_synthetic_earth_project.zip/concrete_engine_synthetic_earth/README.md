# Concrete Engine Synthetic Earth

A holistic procedural demo project for Concrete Engine.

This is not just a fractal viewer. It is a synthetic-world generator that creates:
- terrain
- geology/mineral probability
- roads and infrastructure
- thermal layer
- radar-like layer
- AI feature detections
- Concrete Engine telemetry
- a live dashboard animation

The goal is to show Concrete Engine as a platform that can generate, analyze, and simulate entire operational worlds.

## Install

```bash
python3 -m pip install -r requirements.txt
```

## Run

```bash
python3 run_demo.py
```

## Controls

Close the matplotlib window to stop the demo.

## Project Structure

```text
concrete_engine_synthetic_earth/
  run_demo.py
  requirements.txt
  ce_synthetic_earth/
    config.py
    world.py
    layers.py
    scenarios.py
    detections.py
    telemetry.py
    renderer.py
```

## Concept

The project creates a procedural synthetic world from a seed:

```text
Seed
↓
Terrain
↓
Geology
↓
Infrastructure
↓
Sensor Layers
↓
AI Detections
↓
Mission Dashboard
```

Use cases rotate automatically:
- AI Factory
- Mining
- Border Monitoring
- Agriculture
- Digital Twin
- Sovereign Compute Grid
