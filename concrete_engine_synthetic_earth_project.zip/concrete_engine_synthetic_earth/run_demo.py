from ce_synthetic_earth.config import WorldConfig, RenderConfig, DemoConfig
from ce_synthetic_earth.world import SyntheticWorld
from ce_synthetic_earth.renderer import DashboardRenderer


def main():
    world_config = WorldConfig(
        seed=72,
        size=512,
        terrain_octaves=7,
        terrain_roughness=0.58,
        sea_level=0.36,
    )

    render_config = RenderConfig(
        fps_interval_ms=40,
        particle_count=900,
        show_particles=True,
        show_detections=True,
        show_telemetry=True,
    )

    demo_config = DemoConfig(
        transition_speed=0.006,
        time_step=0.045,
    )

    world = SyntheticWorld.generate(world_config)
    renderer = DashboardRenderer(world, render_config, demo_config)
    renderer.run()


if __name__ == "__main__":
    main()
