"""Concrete Engine Synthetic Earth package."""
