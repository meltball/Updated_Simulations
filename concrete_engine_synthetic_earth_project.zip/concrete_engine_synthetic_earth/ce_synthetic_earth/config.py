from dataclasses import dataclass


@dataclass
class WorldConfig:
    seed: int = 42
    size: int = 512
    terrain_octaves: int = 6
    terrain_roughness: float = 0.58
    sea_level: float = 0.36


@dataclass
class RenderConfig:
    fps_interval_ms: int = 40
    particle_count: int = 900
    show_particles: bool = True
    show_detections: bool = True
    show_telemetry: bool = True


@dataclass
class DemoConfig:
    transition_speed: float = 0.006
    time_step: float = 0.045
