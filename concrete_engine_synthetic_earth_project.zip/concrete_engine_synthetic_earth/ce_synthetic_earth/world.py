from dataclasses import dataclass
import numpy as np

from .config import WorldConfig
from .layers import fbm_noise, generate_fault_lines, generate_geology, generate_infrastructure, generate_sensors


@dataclass
class SyntheticWorld:
    config: WorldConfig
    terrain: np.ndarray
    faults: np.ndarray
    geology: dict
    infrastructure: dict

    @classmethod
    def generate(cls, config: WorldConfig):
        rng = np.random.default_rng(config.seed)
        terrain = fbm_noise(
            config.size,
            rng,
            octaves=config.terrain_octaves,
            persistence=config.terrain_roughness,
        )

        # Make terrain more continent-like.
        y, x = np.mgrid[0:config.size, 0:config.size]
        cx = config.size / 2
        cy = config.size / 2
        radial = np.sqrt((x - cx) ** 2 + (y - cy) ** 2) / (config.size / 1.35)
        terrain = np.clip(terrain - radial * 0.28, 0, 1)
        terrain = (terrain - terrain.min()) / (terrain.max() - terrain.min())

        faults = generate_fault_lines(config.size, rng, count=8)
        geology = generate_geology(terrain, faults, rng)
        infrastructure = generate_infrastructure(terrain, rng)

        return cls(config, terrain, faults, geology, infrastructure)

    def sensors_at(self, t: float) -> dict:
        return generate_sensors(self.terrain, self.geology, self.infrastructure, t)
