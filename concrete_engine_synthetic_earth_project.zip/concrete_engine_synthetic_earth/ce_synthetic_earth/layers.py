import numpy as np


def normalize(arr: np.ndarray) -> np.ndarray:
    arr = arr.astype(float)
    mn = np.nanmin(arr)
    mx = np.nanmax(arr)
    if mx - mn < 1e-9:
        return np.zeros_like(arr)
    return (arr - mn) / (mx - mn)


def fbm_noise(size: int, rng: np.random.Generator, octaves: int = 6, persistence: float = 0.55) -> np.ndarray:
    """
    Simple fractal Brownian noise using progressively upsampled random grids.
    No external noise library required.
    """
    field = np.zeros((size, size), dtype=float)
    amplitude = 1.0
    total_amp = 0.0

    for octave in range(octaves):
        grid_size = max(4, size // (2 ** (octave + 3)))
        coarse = rng.random((grid_size, grid_size))

        # Upsample by repetition, then crop.
        scale = int(np.ceil(size / grid_size))
        up = np.kron(coarse, np.ones((scale, scale)))[:size, :size]

        # Cheap smoothing by neighbor averaging.
        for _ in range(2 + octave):
            up = (
                up
                + np.roll(up, 1, axis=0)
                + np.roll(up, -1, axis=0)
                + np.roll(up, 1, axis=1)
                + np.roll(up, -1, axis=1)
            ) / 5.0

        field += amplitude * up
        total_amp += amplitude
        amplitude *= persistence

    return normalize(field / total_amp)


def gradient_magnitude(arr: np.ndarray) -> np.ndarray:
    gy, gx = np.gradient(arr)
    return normalize(np.sqrt(gx * gx + gy * gy))


def generate_fault_lines(size: int, rng: np.random.Generator, count: int = 7) -> np.ndarray:
    faults = np.zeros((size, size), dtype=float)
    yy, xx = np.mgrid[0:size, 0:size]

    for _ in range(count):
        angle = rng.uniform(0, np.pi)
        cx = rng.uniform(0, size)
        cy = rng.uniform(0, size)
        dist = np.abs((xx - cx) * np.cos(angle) + (yy - cy) * np.sin(angle))
        width = rng.uniform(1.5, 4.0)
        faults += np.exp(-(dist ** 2) / (2 * width ** 2))

    return normalize(faults)


def generate_geology(terrain: np.ndarray, faults: np.ndarray, rng: np.random.Generator) -> dict:
    size = terrain.shape[0]
    deep_noise = fbm_noise(size, rng, octaves=5, persistence=0.62)
    slope = gradient_magnitude(terrain)

    # Mineral probability is intentionally geology-driven, not random:
    # faults + slope + deep structure + certain elevation bands.
    elevation_band = np.exp(-((terrain - 0.55) ** 2) / 0.035)
    mineral = normalize(0.42 * faults + 0.25 * deep_noise + 0.20 * slope + 0.25 * elevation_band)

    # Veins are narrow structures near fault lines.
    veins = normalize((faults > 0.72).astype(float) * (0.5 + deep_noise))

    # Sedimentary / igneous / metamorphic stylized layers.
    sedimentary = normalize((1 - slope) * (terrain < 0.55) * (0.5 + deep_noise))
    igneous = normalize(faults * 0.7 + (terrain > 0.62) * 0.5)
    metamorphic = normalize(slope * 0.6 + faults * 0.5)

    return {
        "mineral": mineral,
        "veins": veins,
        "sedimentary": sedimentary,
        "igneous": igneous,
        "metamorphic": metamorphic,
    }


def generate_infrastructure(terrain: np.ndarray, rng: np.random.Generator) -> dict:
    size = terrain.shape[0]
    yy, xx = np.mgrid[0:size, 0:size]

    roads = np.zeros_like(terrain)
    power = np.zeros_like(terrain)
    cities = np.zeros_like(terrain)
    data_centers = np.zeros_like(terrain)

    # Pick city centers on relatively flat land.
    slope = gradient_magnitude(terrain)
    flat_score = (1 - slope) * (terrain > 0.38) * (terrain < 0.70)

    centers = []
    for _ in range(4):
        idx = np.argmax(flat_score + rng.random(terrain.shape) * 0.05)
        y, x = np.unravel_index(idx, terrain.shape)
        centers.append((x, y))
        dist = np.sqrt((xx - x) ** 2 + (yy - y) ** 2)
        cities += np.exp(-(dist ** 2) / (2 * rng.uniform(13, 24) ** 2))
        flat_score[max(0, y-60):min(size, y+60), max(0, x-60):min(size, x+60)] *= 0.2

    # Roads: connect centers with thickened lines.
    for (x1, y1), (x2, y2) in zip(centers, centers[1:] + centers[:1]):
        steps = int(max(abs(x2 - x1), abs(y2 - y1))) + 1
        xs = np.linspace(x1, x2, steps).astype(int)
        ys = np.linspace(y1, y2, steps).astype(int)
        roads[ys, xs] = 1.0

    for _ in range(3):
        roads = np.maximum.reduce([
            roads,
            np.roll(roads, 1, 0),
            np.roll(roads, -1, 0),
            np.roll(roads, 1, 1),
            np.roll(roads, -1, 1),
        ])

    # Power/fiber follows roads but is thinner and offset.
    power = np.roll(roads, 5, axis=0) * 0.7

    # Data centers near power and flat terrain.
    score = power * (1 - slope) * (terrain > 0.38)
    for _ in range(3):
        idx = np.argmax(score + rng.random(terrain.shape) * 0.02)
        y, x = np.unravel_index(idx, terrain.shape)
        dist = np.sqrt((xx - x) ** 2 + (yy - y) ** 2)
        data_centers += np.exp(-(dist ** 2) / (2 * 8 ** 2))
        score[max(0, y-80):min(size, y+80), max(0, x-80):min(size, x+80)] *= 0.3

    return {
        "roads": normalize(roads),
        "power": normalize(power),
        "cities": normalize(cities),
        "data_centers": normalize(data_centers),
        "centers": centers,
    }


def generate_sensors(terrain: np.ndarray, geology: dict, infra: dict, t: float) -> dict:
    size = terrain.shape[0]
    yy, xx = np.mgrid[0:size, 0:size]
    slope = gradient_magnitude(terrain)

    rgb = normalize(0.50 * terrain + 0.20 * infra["cities"] + 0.10 * infra["roads"] + 0.20 * slope)

    thermal = normalize(
        0.25 * terrain
        + 0.75 * infra["cities"]
        + 0.85 * infra["data_centers"]
        + 0.25 * infra["roads"]
        + 0.05 * np.sin(xx / 10 + t)
    )

    hyperspectral = normalize(
        0.80 * geology["mineral"]
        + 0.65 * geology["veins"]
        + 0.20 * terrain
    )

    radar = normalize(
        0.55 * slope
        + 0.35 * infra["roads"]
        + 0.25 * infra["power"]
        + 0.10 * np.sin((xx + yy) / 18 - t * 2.0)
    )

    lidar = normalize(terrain + 0.12 * infra["cities"] + 0.05 * infra["data_centers"])

    return {
        "rgb": rgb,
        "thermal": thermal,
        "hyperspectral": hyperspectral,
        "radar": radar,
        "lidar": lidar,
    }


def combine_visual_layer(scene: str, sensors: dict, geology: dict, infra: dict, terrain: np.ndarray, t: float) -> np.ndarray:
    """
    Creates a scene-specific visible layer. This replaces random fractals with
    synthetic but meaningful source data.
    """
    scene = scene.upper()

    if scene == "MINING":
        return normalize(
            0.55 * sensors["hyperspectral"]
            + 0.30 * terrain
            + 0.25 * geology["veins"]
            + 0.12 * np.sin(terrain * 18 + t)
        )

    if scene == "BORDER":
        return normalize(
            0.45 * sensors["thermal"]
            + 0.35 * sensors["radar"]
            + 0.20 * infra["roads"]
        )

    if scene == "AGRICULTURE":
        vegetation = normalize((1 - terrain) * (terrain > 0.35) * (terrain < 0.62))
        stress = normalize(0.5 * sensors["thermal"] - 0.3 * vegetation)
        return normalize(0.55 * vegetation + 0.35 * stress + 0.10 * infra["roads"])

    if scene == "DIGITAL_TWIN":
        return normalize(
            0.35 * sensors["lidar"]
            + 0.25 * infra["cities"]
            + 0.25 * infra["roads"]
            + 0.20 * infra["data_centers"]
        )

    if scene == "COMPUTE_GRID":
        return normalize(
            0.50 * infra["data_centers"]
            + 0.35 * infra["power"]
            + 0.30 * infra["roads"]
            + 0.20 * sensors["thermal"]
        )

    # AI_FACTORY
    return normalize(
        0.40 * sensors["thermal"]
        + 0.35 * infra["data_centers"]
        + 0.25 * sensors["radar"]
        + 0.20 * infra["power"]
    )
