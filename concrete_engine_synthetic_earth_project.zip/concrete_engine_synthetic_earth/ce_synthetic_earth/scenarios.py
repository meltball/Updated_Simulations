from dataclasses import dataclass


@dataclass
class Scenario:
    key: str
    title: str
    source: str
    model: str
    mission: str
    cmap: str
    gpu_count: int
    nodes: int
    gpu_load: float
    network: float
    storage: float
    power: float


SCENARIOS = [
    Scenario(
        key="AI_FACTORY",
        title="AI FACTORY // SYNTHETIC DATA + TRAINING",
        source="Synthetic RGB + thermal + radar + generated labels",
        model="CE-ORCHESTRATOR + CE-VISION-7B",
        mission="Generate data, train model, detect convergence",
        cmap="inferno",
        gpu_count=4096,
        nodes=256,
        gpu_load=0.96,
        network=0.92,
        storage=0.89,
        power=0.94,
    ),
    Scenario(
        key="MINING",
        title="MINING // SUBSURFACE MINERAL PROBABILITY",
        source="Synthetic hyperspectral + terrain + geology",
        model="CE-GEOVISION-MINERAL",
        mission="Detect ore veins, faults, and high-density zones",
        cmap="turbo",
        gpu_count=2048,
        nodes=128,
        gpu_load=0.88,
        network=0.70,
        storage=0.82,
        power=0.78,
    ),
    Scenario(
        key="BORDER",
        title="BORDER // MULTI-SENSOR TRACKING",
        source="Synthetic radar + thermal + motion tracks",
        model="CE-MULTISENSOR-TRACKER",
        mission="Track objects, thermal signatures, drone movement",
        cmap="magma",
        gpu_count=1024,
        nodes=96,
        gpu_load=0.81,
        network=0.86,
        storage=0.62,
        power=0.72,
    ),
    Scenario(
        key="AGRICULTURE",
        title="AGRICULTURE // CROP STRESS + YIELD RISK",
        source="Synthetic NDVI-like vegetation + thermal stress",
        model="CE-AGRI-STRESS",
        mission="Detect water stress, crop health, and yield risk",
        cmap="viridis",
        gpu_count=768,
        nodes=64,
        gpu_load=0.66,
        network=0.54,
        storage=0.58,
        power=0.50,
    ),
    Scenario(
        key="DIGITAL_TWIN",
        title="DIGITAL TWIN // CITY + INFRASTRUCTURE ANOMALIES",
        source="Synthetic LiDAR + roads + buildings + sensors",
        model="CE-DIGITAL-TWIN-ANOMALY",
        mission="Compare simulated world against live sensor state",
        cmap="cubehelix",
        gpu_count=1536,
        nodes=112,
        gpu_load=0.78,
        network=0.76,
        storage=0.80,
        power=0.67,
    ),
    Scenario(
        key="COMPUTE_GRID",
        title="SOVEREIGN COMPUTE GRID // AI INFRASTRUCTURE",
        source="Synthetic power + fiber + data center telemetry",
        model="CE-INFRA-OPTIMIZER",
        mission="Optimize distributed GPU sites, power, cooling, routing",
        cmap="plasma",
        gpu_count=8192,
        nodes=512,
        gpu_load=0.98,
        network=0.97,
        storage=0.95,
        power=0.91,
    ),
]
