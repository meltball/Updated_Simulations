import math
import numpy as np
from .layers import normalize


class DetectionEngine:
    """
    Generates use-case specific detections from synthetic source layers.
    This is still synthetic, but now the features are derived from the generated world:
    mineral = hyperspectral hotspots and veins
    border = thermal/radar targets
    agriculture = stress areas
    digital twin = infrastructure anomalies
    compute grid = data center/power hotspots
    """

    def __init__(self, size: int):
        self.size = size

    def top_regions(self, score: np.ndarray, count: int = 5, min_distance: int = 50):
        score = score.copy()
        regions = []

        for _ in range(count):
            idx = np.argmax(score)
            y, x = np.unravel_index(idx, score.shape)
            val = float(score[y, x])
            if val <= 0.01:
                break

            w = int(38 + 45 * val)
            h = int(26 + 35 * val)

            regions.append({
                "x": max(0, x - w // 2) / self.size,
                "y": max(0, y - h // 2) / self.size,
                "w": min(w, self.size) / self.size,
                "h": min(h, self.size) / self.size,
                "score": val,
            })

            y0 = max(0, y - min_distance)
            y1 = min(self.size, y + min_distance)
            x0 = max(0, x - min_distance)
            x1 = min(self.size, x + min_distance)
            score[y0:y1, x0:x1] *= 0.1

        return regions

    def detections(self, scene_key: str, sensors: dict, geology: dict, infra: dict, terrain: np.ndarray, t: float):
        scene_key = scene_key.upper()

        if scene_key == "MINING":
            score = normalize(0.70 * geology["mineral"] + 0.80 * geology["veins"])
            labels = ["ORE VEIN", "SULFIDE BAND", "FAULT INTERSECTION", "HIGH-DENSITY POCKET", "DRILL TARGET"]
            metric = "ORE"
        elif scene_key == "BORDER":
            moving_blobs = self.synthetic_moving_targets(t)
            score = normalize(0.45 * sensors["thermal"] + 0.55 * sensors["radar"] + moving_blobs)
            labels = ["MOVING OBJECT", "THERMAL SIGNATURE", "DRONE TRACK", "PERIMETER BREACH", "VEHICLE TRACK"]
            metric = "TRACK"
        elif scene_key == "AGRICULTURE":
            vegetation = normalize((1 - terrain) * (terrain > 0.35) * (terrain < 0.62))
            stress = normalize(sensors["thermal"] * 0.7 + (1 - vegetation) * 0.4)
            score = stress
            labels = ["WATER STRESS", "LOW NDVI", "CROP HEALTH RISK", "IRRIGATION GAP", "YIELD RISK"]
            metric = "STRESS"
        elif scene_key == "DIGITAL_TWIN":
            score = normalize(0.6 * infra["cities"] + 0.55 * infra["roads"] + 0.7 * infra["data_centers"] + 0.25 * sensors["thermal"])
            labels = ["STRUCTURAL NODE", "HEAT ISLAND", "FLOW BOTTLENECK", "SIMULATION DELTA", "SENSOR ANOMALY"]
            metric = "DELTA"
        elif scene_key == "COMPUTE_GRID":
            score = normalize(0.85 * infra["data_centers"] + 0.55 * infra["power"] + 0.30 * sensors["thermal"])
            labels = ["ACTIVE GPU CLUSTER", "DATAFLOW HOTSPOT", "STORAGE BURST", "POWER NODE", "COOLING ZONE"]
            metric = "LOAD"
        else:
            score = normalize(0.75 * infra["data_centers"] + 0.45 * sensors["thermal"] + 0.30 * sensors["radar"])
            labels = ["MODEL CONVERGENCE", "SYNTHETIC DATA STREAM", "ORCHESTRATION EVENT", "LATENCY DROP", "TRAINING HOTSPOT"]
            metric = "CONF"

        regions = self.top_regions(score, count=5)
        detections = []

        for i, r in enumerate(regions):
            conf = min(0.99, 0.66 + 0.32 * r["score"] + 0.02 * math.sin(t + i))
            detections.append({
                **r,
                "id": 100 + i,
                "label": labels[i % len(labels)],
                "confidence": conf,
                "metric_name": metric,
                "metric_value": self.metric_value(metric, r["score"], t, i),
            })

        return detections

    def synthetic_moving_targets(self, t: float):
        yy, xx = np.mgrid[0:self.size, 0:self.size]
        field = np.zeros((self.size, self.size), dtype=float)

        tracks = [
            (0.25 + 0.18 * math.sin(t * 0.35), 0.30 + 0.10 * math.cos(t * 0.55)),
            (0.62 + 0.15 * math.sin(t * 0.42 + 1.4), 0.48 + 0.16 * math.cos(t * 0.38)),
            (0.72 + 0.10 * math.sin(t * 0.80 + 2.2), 0.72 + 0.08 * math.cos(t * 0.75)),
        ]

        for x, y in tracks:
            cx = x * self.size
            cy = y * self.size
            dist = (xx - cx) ** 2 + (yy - cy) ** 2
            field += np.exp(-dist / (2 * 7.5 ** 2))

        return normalize(field)

    def metric_value(self, metric: str, score: float, t: float, i: int) -> str:
        if metric == "ORE":
            return f"ORE {score * 100:.0f}%"
        if metric == "TRACK":
            return f"VEL {12 + 10 * abs(math.sin(t + i)):.1f}m/s"
        if metric == "STRESS":
            return f"STRESS {score * 100:.0f}%"
        if metric == "DELTA":
            return f"Δ {score * 100:.0f}%"
        if metric == "LOAD":
            return f"LOAD {score * 100:.0f}%"
        return f"CONF {score * 100:.0f}%"
