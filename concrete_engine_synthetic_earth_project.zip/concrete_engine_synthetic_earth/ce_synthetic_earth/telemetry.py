import math


def telemetry_for(scenario, t: float) -> dict:
    pulse = 0.5 + 0.5 * math.sin(t * 1.7)

    return {
        "GPU LOAD": f"{min(0.99, scenario.gpu_load + 0.025 * pulse):.0%}",
        "GPUs": f"{scenario.gpu_count:,}",
        "NODES": f"{scenario.nodes:,}",
        "NETWORK": f"{min(0.99, scenario.network + 0.03 * pulse):.0%}",
        "STORAGE": f"{min(0.99, scenario.storage + 0.02 * pulse):.0%}",
        "POWER": f"{min(0.99, scenario.power + 0.015 * pulse):.0%}",
        "PUE": f"{1.02 + (1 - scenario.power) * 0.08:.2f}",
        "BATCH": f"{int(12000 + 4000 * pulse):,}",
        "LATENCY": f"{7.5 + 2.0 * (1 - scenario.network):.1f} ms",
        "STATUS": "ANALYZING",
    }
