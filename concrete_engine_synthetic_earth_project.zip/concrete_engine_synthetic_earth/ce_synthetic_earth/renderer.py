import math
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

from .config import RenderConfig, DemoConfig
from .world import SyntheticWorld
from .scenarios import SCENARIOS
from .layers import combine_visual_layer, normalize
from .detections import DetectionEngine
from .telemetry import telemetry_for


class ParticleSystem:
    def __init__(self, count: int, rng: np.random.Generator):
        self.count = count
        self.rng = rng
        self.x = rng.uniform(0, 1, count)
        self.y = rng.uniform(0, 1, count)
        self.vx = rng.normal(0, 0.0018, count)
        self.vy = rng.normal(0, 0.0018, count)

    def update(self, t: float, scene_key: str):
        # Particles behave differently by use case.
        if scene_key in ("AI_FACTORY", "COMPUTE_GRID"):
            cx, cy = 0.5, 0.5
            dx = self.x - cx
            dy = self.y - cy
            angle = np.arctan2(dy, dx) + np.pi / 2
            self.vx += 0.00018 * np.cos(angle)
            self.vy += 0.00018 * np.sin(angle)
        elif scene_key == "BORDER":
            self.vx += 0.00012
            self.vy += 0.00003 * np.sin(t + self.x * 8)
        else:
            self.vx += 0.00002 * np.sin(t + self.y * 5)
            self.vy += 0.00002 * np.cos(t + self.x * 5)

        self.x = (self.x + self.vx) % 1.0
        self.y = (self.y + self.vy) % 1.0
        self.vx *= 0.995
        self.vy *= 0.995


class ScenarioPlayer:
    def __init__(self, scenarios, transition_speed: float):
        self.scenarios = scenarios
        self.index = 0
        self.transition = 0.0
        self.transition_speed = transition_speed

    def current(self):
        scenario = self.scenarios[self.index % len(self.scenarios)]
        self.transition += self.transition_speed
        if self.transition >= 1.0:
            self.transition = 0.0
            self.index += 1
        return scenario


class DashboardRenderer:
    def __init__(self, world: SyntheticWorld, render_config: RenderConfig, demo_config: DemoConfig):
        self.world = world
        self.render_config = render_config
        self.demo_config = demo_config
        self.detector = DetectionEngine(world.config.size)
        self.player = ScenarioPlayer(SCENARIOS, demo_config.transition_speed)
        self.rng = np.random.default_rng(world.config.seed + 99)
        self.particles = ParticleSystem(render_config.particle_count, self.rng)
        self.t = 0.0
        self.dynamic_artists = []

    def run(self):
        scenario = self.player.current()
        sensors = self.world.sensors_at(self.t)
        layer = combine_visual_layer(
            scenario.key,
            sensors,
            self.world.geology,
            self.world.infrastructure,
            self.world.terrain,
            self.t,
        )

        fig, ax = plt.subplots(figsize=(10, 10))
        fig.canvas.manager.set_window_title("Concrete Engine Synthetic Earth")
        ax.set_facecolor("black")
        ax.axis("off")

        im = ax.imshow(layer, cmap=scenario.cmap, interpolation="bilinear", animated=True)

        scatter = ax.scatter([], [], s=1.0, alpha=0.50, c="white")

        title = ax.text(
            0.02, 0.965, "",
            transform=ax.transAxes,
            fontsize=14,
            weight="bold",
            color="white",
            family="monospace",
        )

        subtitle = ax.text(
            0.02, 0.925, "",
            transform=ax.transAxes,
            fontsize=8.5,
            color="white",
            family="monospace",
        )

        telemetry = ax.text(
            0.02, 0.045, "",
            transform=ax.transAxes,
            fontsize=8.5,
            color="white",
            family="monospace",
            bbox=dict(boxstyle="round,pad=0.35", facecolor="black", edgecolor="white", alpha=0.35),
        )

        source = ax.text(
            0.02, 0.885, "",
            transform=ax.transAxes,
            fontsize=8,
            color="white",
            family="monospace",
            bbox=dict(boxstyle="round,pad=0.25", facecolor="black", edgecolor="white", alpha=0.25),
        )

        def update(_frame):
            self.clear_dynamic()
            self.t += self.demo_config.time_step

            scenario = self.player.current()
            sensors = self.world.sensors_at(self.t)

            layer = combine_visual_layer(
                scenario.key,
                sensors,
                self.world.geology,
                self.world.infrastructure,
                self.world.terrain,
                self.t,
            )

            # Add cinematic pulse/noise without destroying source-layer meaning.
            layer = normalize(
                layer
                + 0.05 * np.sin(layer * 18 + self.t * 2.2)
                + 0.025 * self.rng.normal(0, 1, layer.shape)
            )

            im.set_array(layer)
            im.set_cmap(scenario.cmap)

            title.set_text(scenario.title)
            subtitle.set_text(f"MISSION: {scenario.mission}")
            source.set_text(f"INPUT: {scenario.source}\nMODEL: {scenario.model}")

            tel = telemetry_for(scenario, self.t)
            telemetry.set_text("  ".join([f"{k}: {v}" for k, v in tel.items()]))

            if self.render_config.show_particles:
                self.particles.update(self.t, scenario.key)
                scatter.set_offsets(np.column_stack([
                    self.particles.x * self.world.config.size,
                    self.particles.y * self.world.config.size,
                ]))

            if self.render_config.show_detections:
                detections = self.detector.detections(
                    scenario.key,
                    sensors,
                    self.world.geology,
                    self.world.infrastructure,
                    self.world.terrain,
                    self.t,
                )
                self.dynamic_artists.extend(self.draw_detections(ax, detections, self.t, scenario.key))

            self.dynamic_artists.extend(self.draw_scene_specific_overlays(ax, scenario.key, self.t))

            return [im, scatter, title, subtitle, telemetry, source] + self.dynamic_artists

        ani = FuncAnimation(
            fig,
            update,
            interval=self.render_config.fps_interval_ms,
            blit=False,
            cache_frame_data=False,
        )
        plt.show()
        return ani

    def clear_dynamic(self):
        for artist in self.dynamic_artists:
            try:
                artist.remove()
            except Exception:
                pass
        self.dynamic_artists = []

    def draw_detections(self, ax, detections, t: float, scene_key: str):
        artists = []
        size = self.world.config.size

        for d in detections:
            x = d["x"] * size
            y = d["y"] * size
            w = d["w"] * size
            h = d["h"] * size
            conf = d["confidence"]
            alpha = 0.45 + 0.35 * conf

            rect = plt.Rectangle(
                (x, y),
                w,
                h,
                fill=False,
                edgecolor="white",
                linewidth=1.1,
                alpha=alpha,
            )
            ax.add_patch(rect)
            artists.append(rect)

            # Shorter corner accents look more operational than huge boxes.
            c = min(w, h) * 0.22
            for x1, y1, x2, y2 in [
                (x, y, x + c, y), (x, y, x, y + c),
                (x + w, y, x + w - c, y), (x + w, y, x + w, y + c),
                (x, y + h, x + c, y + h), (x, y + h, x, y + h - c),
                (x + w, y + h, x + w - c, y + h), (x + w, y + h, x + w, y + h - c),
            ]:
                line, = ax.plot([x1, x2], [y1, y2], color="white", linewidth=2.0, alpha=alpha)
                artists.append(line)

            label = f"ID-{d['id']} {d['label']} {conf:.0%} {d['metric_value']}"
            txt = ax.text(
                x,
                max(8, y - 9),
                label,
                fontsize=7.2,
                color="white",
                family="monospace",
                bbox=dict(boxstyle="round,pad=0.22", facecolor="black", edgecolor="white", alpha=0.48, linewidth=0.55),
            )
            artists.append(txt)

            cx, cy = x + w / 2, y + h / 2
            dot = ax.scatter([cx], [cy], s=12, c="white", alpha=alpha)
            artists.append(dot)

            if scene_key == "BORDER":
                # Predicted track vector.
                dx = 24 * math.sin(t + d["id"])
                dy = 16 * math.cos(t * 0.7 + d["id"])
                arrow = ax.arrow(cx, cy, dx, dy, color="white", alpha=0.45, width=0.25, head_width=5)
                artists.append(arrow)

        return artists

    def draw_scene_specific_overlays(self, ax, scene_key: str, t: float):
        artists = []
        size = self.world.config.size

        if scene_key == "BORDER":
            # Radar sweep.
            cx = cy = size / 2
            angle = t * 1.3
            x2 = cx + math.cos(angle) * size * 0.48
            y2 = cy + math.sin(angle) * size * 0.48
            line, = ax.plot([cx, x2], [cy, y2], color="white", alpha=0.28, linewidth=1.4)
            artists.append(line)

            ring = plt.Circle((cx, cy), size * 0.32, fill=False, color="white", alpha=0.18, linewidth=0.8)
            ax.add_patch(ring)
            artists.append(ring)

        if scene_key == "MINING":
            # Drill-hole points.
            rng = np.random.default_rng(5)
            xs = rng.uniform(size * 0.18, size * 0.82, 18)
            ys = rng.uniform(size * 0.22, size * 0.80, 18)
            pts = ax.scatter(xs, ys, s=8, facecolors="none", edgecolors="white", alpha=0.55)
            artists.append(pts)

        if scene_key in ("AI_FACTORY", "COMPUTE_GRID"):
            # Data center node pulses, not full grids.
            dc = self.world.infrastructure["data_centers"]
            yx = np.argwhere(dc > 0.72)
            if len(yx) > 0:
                sample = yx[::max(1, len(yx)//30)]
                pulse = 28 + 15 * abs(math.sin(t * 2.0))
                pts = ax.scatter(sample[:, 1], sample[:, 0], s=pulse, facecolors="none", edgecolors="white", alpha=0.35)
                artists.append(pts)

        return artists
