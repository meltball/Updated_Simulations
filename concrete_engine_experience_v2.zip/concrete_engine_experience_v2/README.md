# Concrete Engine Experience V2

This version should look different from the old one.

It uses a multi-panel mission dashboard:
- Large mission view
- Source sensor layer
- Analysis layer
- AI latent-space layer
- Telemetry / detections panel

Run:

```bash
python3 -m pip install -r requirements.txt
python3 run_v2.py
```

Export preview GIF:

```bash
python3 export_v2_gif.py
```
