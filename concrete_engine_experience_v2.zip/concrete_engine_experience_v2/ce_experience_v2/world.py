
import numpy as np

def normalize(a):
    a = a.astype(float)
    mn, mx = np.min(a), np.max(a)
    if mx - mn < 1e-9:
        return np.zeros_like(a)
    return (a - mn) / (mx - mn)

def smooth(a, rounds=2):
    for _ in range(rounds):
        a = (a + np.roll(a,1,0)+np.roll(a,-1,0)+np.roll(a,1,1)+np.roll(a,-1,1))/5
    return a

def fbm(size, rng, octaves=7):
    out=np.zeros((size,size)); amp=1; total=0
    for i in range(octaves):
        g=max(4,size//(2**(i+3)))
        coarse=rng.random((g,g))
        scale=int(np.ceil(size/g))
        up=np.kron(coarse,np.ones((scale,scale)))[:size,:size]
        up=smooth(up,2+i)
        out+=amp*up; total+=amp; amp*=.58
    return normalize(out/total)

def gradient(a):
    gy,gx=np.gradient(a)
    return normalize(np.sqrt(gx*gx+gy*gy))

def fault_layer(size,rng):
    yy,xx=np.mgrid[0:size,0:size]
    out=np.zeros((size,size))
    for _ in range(10):
        angle=rng.uniform(0,np.pi)
        cx,cy=rng.uniform(0,size),rng.uniform(0,size)
        dist=np.abs((xx-cx)*np.cos(angle)+(yy-cy)*np.sin(angle))
        out+=np.exp(-(dist**2)/(2*rng.uniform(1.4,4.2)**2))
    return normalize(out)

class World:
    def __init__(self,size=420,seed=72):
        self.size=size
        rng=np.random.default_rng(seed)
        self.terrain=fbm(size,rng,8)
        yy,xx=np.mgrid[0:size,0:size]
        radial=np.sqrt((xx-size/2)**2+(yy-size/2)**2)/(size/1.35)
        self.terrain=normalize(np.clip(self.terrain-radial*.30,0,1))
        self.slope=gradient(self.terrain)
        self.faults=fault_layer(size,rng)
        deep=fbm(size,rng,5)
        band=np.exp(-((self.terrain-.56)**2)/.035)
        self.mineral=normalize(.50*self.faults+.28*deep+.22*self.slope+.28*band)
        self.veins=normalize((self.faults>.70).astype(float)*(.5+deep))

        flat=(1-self.slope)*(self.terrain>.36)*(self.terrain<.72)
        self.cities=np.zeros((size,size)); self.roads=np.zeros((size,size))
        centers=[]; score=flat.copy()
        for _ in range(5):
            idx=np.argmax(score+rng.random(score.shape)*.05)
            y,x=np.unravel_index(idx,score.shape)
            centers.append((x,y))
            dist=np.sqrt((xx-x)**2+(yy-y)**2)
            self.cities+=np.exp(-(dist**2)/(2*rng.uniform(12,25)**2))
            score[max(0,y-70):min(size,y+70),max(0,x-70):min(size,x+70)]*=.12
        for (x1,y1),(x2,y2) in zip(centers,centers[1:]+centers[:1]):
            steps=int(max(abs(x2-x1),abs(y2-y1)))+1
            xs=np.linspace(x1,x2,steps).astype(int)
            ys=np.linspace(y1,y2,steps).astype(int)
            self.roads[ys,xs]=1
        self.roads=normalize(smooth(self.roads,4))
        self.power=normalize(np.roll(self.roads,5,0)*.8)
        self.data_centers=np.zeros((size,size))
        dc_score=self.power*flat
        for _ in range(4):
            idx=np.argmax(dc_score+rng.random(dc_score.shape)*.03)
            y,x=np.unravel_index(idx,dc_score.shape)
            dist=np.sqrt((xx-x)**2+(yy-y)**2)
            self.data_centers+=np.exp(-(dist**2)/(2*7**2))
            dc_score[max(0,y-75):min(size,y+75),max(0,x-75):min(size,x+75)]*=.1
        self.cities=normalize(self.cities); self.data_centers=normalize(self.data_centers)

    def sensors(self,t):
        size=self.size
        yy,xx=np.mgrid[0:size,0:size]
        rgb=normalize(.55*self.terrain+.20*self.cities+.18*self.roads+.18*self.slope)
        thermal=normalize(.20*self.terrain+.75*self.cities+1.0*self.data_centers+.20*self.roads+.05*np.sin(xx/9+t))
        radar=normalize(.55*self.slope+.35*self.roads+.32*self.power+.12*np.sin((xx+yy)/15-t*2.2))
        hyper=normalize(.85*self.mineral+.75*self.veins+.15*self.terrain)
        lidar=normalize(self.terrain+.15*self.cities+.08*self.data_centers)
        ndvi=normalize((1-self.terrain)*(self.terrain>.34)*(self.terrain<.63)-.20*thermal)
        return dict(rgb=rgb, thermal=thermal, radar=radar, hyper=hyper, lidar=lidar, ndvi=ndvi)

    def latent(self,t):
        size=self.size
        y,x=np.mgrid[-1:1:complex(size),-1:1:complex(size)]
        r=np.sqrt(x*x+y*y)
        a=np.arctan2(y,x)
        z=np.sin(18*r-t*3)+np.cos(9*a+t)+np.sin((x+y)*18+t*2)
        return normalize(z)
