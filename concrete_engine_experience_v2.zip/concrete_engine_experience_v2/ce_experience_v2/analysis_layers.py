
import numpy as np
from .world import normalize

def moving_targets(size,t):
    yy,xx=np.mgrid[0:size,0:size]
    out=np.zeros((size,size))
    pts=[
        (.25+.18*np.sin(t*.35),.30+.10*np.cos(t*.55)),
        (.62+.15*np.sin(t*.42+1.4),.48+.16*np.cos(t*.38)),
        (.72+.10*np.sin(t*.80+2.2),.72+.08*np.cos(t*.75)),
        (.38+.12*np.sin(t*.55+4.0),.70+.07*np.cos(t*.65)),
    ]
    for x,y in pts:
        cx=x*size; cy=y*size
        d=(xx-cx)**2+(yy-cy)**2
        out+=np.exp(-d/(2*8.0**2))
        out+=.35*np.exp(-((xx-(cx-25*np.sin(t)))**2+(yy-(cy-14*np.cos(t)))**2)/(2*14**2))
    return normalize(out)

def source_layer(scene, world, sensor, t):
    if scene.key=="MINING": return sensor["hyper"]
    if scene.key=="BORDER": return normalize(.55*sensor["thermal"]+.45*sensor["radar"])
    if scene.key=="AGRICULTURE": return sensor["ndvi"]
    if scene.key=="DIGITAL_TWIN": return normalize(.55*sensor["lidar"]+.25*world.roads+.25*world.cities)
    if scene.key=="COMPUTE_GRID": return normalize(.60*world.power+.55*world.data_centers+.25*sensor["thermal"])
    return normalize(.60*sensor["thermal"]+.45*world.data_centers+.25*world.power)

def analysis_layer(scene, world, sensor, t):
    if scene.key=="MINING": return normalize(.70*world.mineral+.85*world.veins+.30*world.faults)
    if scene.key=="BORDER": return moving_targets(world.size,t)
    if scene.key=="AGRICULTURE": return normalize((1-sensor["ndvi"])*.70+sensor["thermal"]*.45)
    if scene.key=="DIGITAL_TWIN": return normalize(.45*world.cities+.45*world.roads+.75*world.data_centers+.25*sensor["thermal"])
    if scene.key=="COMPUTE_GRID": return normalize(.85*world.data_centers+.65*world.power+.20*sensor["thermal"])
    return normalize(.85*world.data_centers+.45*sensor["thermal"]+.35*sensor["radar"])
