
from dataclasses import dataclass

@dataclass
class Scene:
    key: str
    title: str
    source_title: str
    analysis_title: str
    model: str
    mission: str
    cmap_source: str
    cmap_analysis: str
    duration: float
    gpu: int
    nodes: int
    load: float

SCENES=[
    Scene("AI_FACTORY","AI FACTORY CONTROL","THERMAL + POWER SOURCE","GPU JOB ORCHESTRATION","CE-ORCHESTRATOR","Move workloads across distributed AI factories","inferno","plasma",25,8192,512,.98),
    Scene("MINING","MINING INTELLIGENCE","HYPERSPECTRAL SOURCE","ORE PROBABILITY + FAULTS","CE-GEOVISION","Find drill targets from synthetic geology","terrain","turbo",28,2048,128,.88),
    Scene("BORDER","BORDER MULTI-SENSOR","THERMAL / RADAR SOURCE","TARGET TRACKING","CE-TRACKER","Detect motion, thermal signatures, and predicted paths","magma","gray",25,1024,96,.82),
    Scene("AGRICULTURE","AGRICULTURE MONITOR","NDVI SOURCE","CROP STRESS ANALYSIS","CE-AGRI","Detect water stress and yield risk","Greens","viridis",25,768,64,.66),
    Scene("DIGITAL_TWIN","DIGITAL TWIN OPS","LIDAR + INFRASTRUCTURE SOURCE","SIMULATION DELTA","CE-TWIN","Compare generated world against sensor state","cubehelix","cividis",26,1536,112,.78),
    Scene("COMPUTE_GRID","SOVEREIGN COMPUTE GRID","POWER + FIBER SOURCE","DATA CENTER OPTIMIZATION","CE-INFRA","Optimize GPU sites, power, and routing","bone","plasma",28,8192,512,.97),
]

class Director:
    def __init__(self):
        self.total=sum(s.duration for s in SCENES)
    def at(self,t):
        t=t%self.total
        acc=0
        for s in SCENES:
            if acc<=t<acc+s.duration:
                return s,(t-acc)/s.duration
            acc+=s.duration
        return SCENES[-1],1
