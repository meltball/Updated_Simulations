
import math
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter

from .world import World, normalize
from .scenes import Director
from .analysis_layers import source_layer, analysis_layer

class DashboardV2:
    def __init__(self,size=420):
        self.world=World(size=size)
        self.director=Director()
        self.t=0
        self.rng=np.random.default_rng(99)
        self.dynamic=[]

    def setup(self):
        fig=plt.figure(figsize=(13,8), facecolor="black")
        try: fig.canvas.manager.set_window_title("Concrete Engine Experience V2")
        except Exception: pass
        ax_main=fig.add_axes([.03,.09,.44,.78])
        ax_src=fig.add_axes([.51,.55,.20,.30])
        ax_analysis=fig.add_axes([.74,.55,.23,.30])
        ax_latent=fig.add_axes([.51,.12,.20,.30])
        ax_tele=fig.add_axes([.74,.12,.23,.30])
        axes=[ax_main,ax_src,ax_analysis,ax_latent,ax_tele]
        for ax in axes:
            ax.set_facecolor("black"); ax.set_xticks([]); ax.set_yticks([])
            for sp in ax.spines.values():
                sp.set_edgecolor("white"); sp.set_alpha(.35)
        s,_=self.director.at(0)
        sensor=self.world.sensors(0)
        src=source_layer(s,self.world,sensor,0)
        ana=analysis_layer(s,self.world,sensor,0)
        lat=self.world.latent(0)
        handles={
            "main": ax_main.imshow(src, cmap=s.cmap_source, interpolation="bilinear"),
            "src": ax_src.imshow(src, cmap=s.cmap_source, interpolation="bilinear"),
            "analysis": ax_analysis.imshow(ana, cmap=s.cmap_analysis, interpolation="bilinear"),
            "latent": ax_latent.imshow(lat, cmap="inferno", interpolation="bilinear"),
            "title": fig.text(.03,.94,"",color="white",fontsize=18,weight="bold",family="monospace"),
            "subtitle": fig.text(.03,.905,"",color="white",fontsize=10,family="monospace"),
            "src_title": fig.text(.51,.87,"",color="white",fontsize=9,weight="bold",family="monospace"),
            "analysis_title": fig.text(.74,.87,"",color="white",fontsize=9,weight="bold",family="monospace"),
            "latent_title": fig.text(.51,.44,"AI LATENT SPACE",color="white",fontsize=9,weight="bold",family="monospace"),
            "tele_title": fig.text(.74,.44,"CONCRETE ENGINE TELEMETRY",color="white",fontsize=9,weight="bold",family="monospace"),
            "tele": ax_tele.text(.03,.95,"", transform=ax_tele.transAxes, color="white", fontsize=9, family="monospace", va="top"),
            "caption": fig.text(.03,.035,"CONCRETE ENGINE  //  Generate. Analyze. Simulate. Scale.",color="white",fontsize=10,weight="bold",family="monospace"),
        }
        return fig, (ax_main,ax_src,ax_analysis,ax_latent,ax_tele), handles

    def clear(self):
        for a in self.dynamic:
            try: a.remove()
            except Exception: pass
        self.dynamic=[]

    def update(self, axes, h, dt=.06):
        self.clear()
        self.t+=dt
        scene,progress=self.director.at(self.t)
        sensor=self.world.sensors(self.t)
        src=source_layer(scene,self.world,sensor,self.t)
        ana=analysis_layer(scene,self.world,sensor,self.t)
        lat=self.world.latent(self.t)
        if scene.key in ["MINING","AGRICULTURE"]:
            main=normalize(.65*src+.45*ana)
        elif scene.key=="BORDER":
            main=normalize(.45*src+.85*ana)
        elif scene.key in ["AI_FACTORY","COMPUTE_GRID"]:
            main=normalize(.35*src+.85*ana+.20*lat)
        else:
            main=normalize(.50*src+.55*ana+.15*lat)
        main=normalize(main+.025*self.rng.normal(0,1,main.shape)+.035*np.sin(main*20+self.t*2))
        h["main"].set_data(main); h["main"].set_cmap(scene.cmap_source)
        h["src"].set_data(normalize(src+.015*self.rng.normal(0,1,src.shape))); h["src"].set_cmap(scene.cmap_source)
        h["analysis"].set_data(normalize(ana+.015*self.rng.normal(0,1,ana.shape))); h["analysis"].set_cmap(scene.cmap_analysis)
        h["latent"].set_data(lat)
        h["title"].set_text(scene.title)
        h["subtitle"].set_text(f"MISSION: {scene.mission}   |   MODEL: {scene.model}")
        h["src_title"].set_text(scene.source_title)
        h["analysis_title"].set_text(scene.analysis_title)
        h["tele"].set_text(self.telemetry(scene,progress))
        ax_main,ax_src,ax_analysis,ax_latent,ax_tele=axes
        self.draw_scene_overlays(ax_main,scene,ana)
        self.draw_detection_list(ax_tele,scene,ana)
        return list(h.values())+self.dynamic

    def telemetry(self,scene,progress):
        pulse=.5+.5*math.sin(self.t*1.7)
        return (
            f"SCENE        {scene.key}\n"
            f"PROGRESS     {progress*100:05.1f}%\n\n"
            f"GPU LOAD     {min(.99,scene.load+.02*pulse):05.1%}\n"
            f"GPUs         {scene.gpu:,}\n"
            f"NODES        {scene.nodes:,}\n"
            f"NETWORK      {min(.99,.72+.20*pulse):05.1%}\n"
            f"STORAGE      {min(.99,.68+.18*pulse):05.1%}\n"
            f"PUE          {1.03+(1-scene.load)*.05:.2f}\n\n"
            f"STATUS       ANALYZING\n"
            f"MODE         SYNTHETIC WORLD\n"
            f"OUTPUT       FEATURE MAP"
        )

    def draw_detection_list(self,ax,scene,ana):
        label_map={
            "MINING":["ORE VEIN","FAULT INTERSECTION","DRILL TARGET","SULFIDE BAND"],
            "BORDER":["MOVING OBJECT","THERMAL SIGNATURE","DRONE TRACK","PREDICTED PATH"],
            "AGRICULTURE":["WATER STRESS","LOW NDVI","YIELD RISK","IRRIGATION GAP"],
            "DIGITAL_TWIN":["HEAT ISLAND","FLOW BOTTLENECK","SENSOR DELTA","STRUCTURAL NODE"],
            "COMPUTE_GRID":["GPU CLUSTER","DATAFLOW HOTSPOT","POWER NODE","COOLING ZONE"],
            "AI_FACTORY":["MODEL CONVERGENCE","JOB MIGRATION","LATENCY DROP","TRAINING HOTSPOT"],
        }
        labels=label_map[scene.key]
        vals=np.sort(ana.ravel())[-4:][::-1]
        y=.60
        for i,(lab,val) in enumerate(zip(labels,vals)):
            txt=ax.text(.05,y-i*.11,f"ID-{100+i}  {lab:<20} {min(.99,.65+.34*val):.0%}", transform=ax.transAxes,
                        color="white", fontsize=8, family="monospace",
                        bbox=dict(facecolor="black", edgecolor="white", alpha=.25, pad=2))
            self.dynamic.append(txt)

    def draw_scene_overlays(self,ax,scene,ana):
        size=self.world.size
        score=ana.copy()
        for i in range(4):
            y,x=np.unravel_index(np.argmax(score),score.shape)
            val=score[y,x]
            if val<.02: break
            w=28+45*val; ht=20+30*val
            if scene.key=="MINING":
                circ=plt.Circle((x,y),w*.55,fill=False,color="white",alpha=.45,linewidth=1.4)
                ax.add_patch(circ); self.dynamic.append(circ)
                p=ax.scatter([x],[y],s=18,facecolors="none",edgecolors="white",alpha=.8); self.dynamic.append(p)
            elif scene.key=="BORDER":
                p=ax.scatter([x],[y],s=30,c="white",alpha=.75); self.dynamic.append(p)
                ar=ax.arrow(x,y,30*math.sin(self.t+i),18*math.cos(self.t*.7+i),color="white",alpha=.5,width=.5,head_width=5)
                self.dynamic.append(ar)
            elif scene.key in ["COMPUTE_GRID","AI_FACTORY"]:
                circ=plt.Circle((x,y),w*.45,fill=False,color="white",alpha=.32+.25*math.sin(self.t*2+i),linewidth=1.5)
                ax.add_patch(circ); self.dynamic.append(circ)
                p=ax.scatter([x],[y],s=60,facecolors="none",edgecolors="white",alpha=.55); self.dynamic.append(p)
            else:
                rect=plt.Rectangle((x-w/2,y-ht/2),w,ht,fill=False,edgecolor="white",alpha=.55,linewidth=1.2)
                ax.add_patch(rect); self.dynamic.append(rect)
            score[max(0,y-45):min(size,y+45),max(0,x-45):min(size,x+45)]*=.08
        if scene.key=="BORDER":
            cx=cy=size/2
            angle=self.t*1.5
            line,=ax.plot([cx,cx+math.cos(angle)*size*.48],[cy,cy+math.sin(angle)*size*.48],color="white",alpha=.28,lw=1.3)
            self.dynamic.append(line)

    def run(self):
        fig,axes,h=self.setup()
        def upd(_): return self.update(axes,h,.06)
        ani=FuncAnimation(fig,upd,interval=40,blit=False,cache_frame_data=False)
        plt.show()
        return ani

    def export_gif(self,path,seconds=24,fps=12):
        fig,axes,h=self.setup()
        def upd(_): return self.update(axes,h,1/fps)
        ani=FuncAnimation(fig,upd,frames=seconds*fps,interval=1000/fps,blit=False,cache_frame_data=False)
        ani.save(path,writer=PillowWriter(fps=fps))
        plt.close(fig)
        return path
