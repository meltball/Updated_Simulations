from ce_experience_v2.renderer import DashboardV2

if __name__ == "__main__":
    DashboardV2(size=420).run()
