from ce_experience_v2.renderer import DashboardV2

if __name__ == "__main__":
    out = DashboardV2(size=360).export_gif("concrete_engine_experience_v2_preview.gif", seconds=24, fps=12)
    print(f"Saved {out}")
